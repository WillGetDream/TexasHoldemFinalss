/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DeckOfCards.h
 * Author: william
 *
 * Created on October 29, 2019, 8:46 PM
 */

#ifndef DECKOFCARDS_H
#define DECKOFCARDS_H

#include "Card.h"
#include <stack>

class DeckOfCards {

private:
    Card deck[52]; // an array of cards of size SIZR
    stack<Card> deckList;
    int currentCard;

public:
    DeckOfCards();
    stack<Card> shuffle();
    Card dealCard();

};



#endif /* DECKOFCARDS_H */

