/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Position.h
 * Author: william
 *
 * Created on October 29, 2019, 8:47 PM
 */

#ifndef POSITION_H
#define POSITION_H


#include <string>
using namespace std;
struct Position{
    string UTG="UTG";
    string MP="MP";
    string CO="CO";
    string BTN="BTN";
    string SB="SB";
    string BB="BB";
};

#endif /* POSITION_H */

