//
// Created by william shuai xiong on 10/20/19.
//

#ifndef TEXASHOLDEM_POSITION_H
#define TEXASHOLDEM_POSITION_H

#include <string>
using namespace std;
struct Position{
    string UTG="UTG";
    string MP="MP";
    string CO="CO";
    string BTN="BTN";
    string SB="SB";
    string BB="BB";
};

#endif //TEXASHOLDEM_POSITION_H
