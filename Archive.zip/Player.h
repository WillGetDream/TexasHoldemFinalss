/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: william
 *
 * Created on October 29, 2019, 8:47 PM
 */

#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "Card.h"
using namespace std;

class Player {
public:
    string name;
    int chips;
    int chipsOnTable;
    string position;
    Card card[2];
    string status; //fold, active, allin
    int sidePot;
    int valueInHand;

    Player(){};

    Player(string name,int chips){
        this->name=name;
        this->chips=chips;
    }



};


#endif /* PLAYER_H */

