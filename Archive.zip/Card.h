/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Card.h
 * Author: william
 *
 * Created on October 29, 2019, 8:52 PM
 */

#ifndef CARD_H
#define CARD_H

#include <string>
using namespace std;

class Card
{

private:
    string face;
    string suit;

public:
    Card();
    string print();
    Card(string cardFace, string cardSuit);
    int getFace(){
        if(!face.compare("Ace")){
            return 14;
        }else if(!face.compare("J")){
            return 11;
        }else if(!face.compare("Q")){
            return 12;
        }else if(!face.compare("K")){
            return 13;
        }else{
            return atoi(face.c_str() );
        }

      };
    string getSuit(){return suit;};
};




#endif /* CARD_H */

